<div <?php echo e($attributes->class(['fi-dropdown-list'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH D:\My Work\Laravel\almobtaker-website\vendor\filament\support\resources\views/components/dropdown/list/index.blade.php ENDPATH**/ ?>