<div class="flex items-center gap-3 ms-2 me-2">
    <a href="/" target="_blank" class="cyber-live-btn">
        <i class="fa-solid fa-globe"></i>
        <span>معاينة الموقع الحي</span>
    </a>
</div>
<?php /**PATH D:\My Work\Laravel\almobtaker-website\resources\views/filament/topbar-live-site.blade.php ENDPATH**/ ?>